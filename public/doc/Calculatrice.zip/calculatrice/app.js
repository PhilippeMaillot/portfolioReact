const calculator = document.querySelector('.calculator');
const display = calculator.querySelector('.display');
const keys = calculator.querySelectorAll('.btn');
const buttons = document.querySelectorAll('.btn');

buttons.forEach(button => {
  button.addEventListener('click', () => {
    button.classList.add('clicked');
    setTimeout(() => {
      button.classList.remove('clicked');
    }, 100);
  });
});

let lastOperator = null;
let shouldClearDisplay = false;

Array.from(keys).forEach(key => {
  key.addEventListener('click', () => {
    const keyValue = key.getAttribute('value');
    const displayValue = display.value;

    if (keyValue === 'C') {
      display.value = '';
      lastOperator = null;
      shouldClearDisplay = false;
    } else if (keyValue === '=') {
      try {
        const result = eval(displayValue);
        display.value = result.toPrecision();
        lastOperator = null;
        shouldClearDisplay = true;
      } catch (error) {
        display.value = 'Error';
      }
    } else if (keyValue === 'log') {
      const result = Math.log10(displayValue);
      display.value = result.toPrecision(4);
      lastOperator = null;
      shouldClearDisplay = true;
    } else if (keyValue === 'exp') {
      const result = Math.exp(displayValue);
      display.value = result.toPrecision(4);
      lastOperator = null;
      shouldClearDisplay = true;
    } else if (keyValue === '(') {
      display.value = displayValue + keyValue;
      lastOperator = null;
      shouldClearDisplay = false;
    } else if (keyValue === ')') {
      display.value = displayValue + keyValue;
      lastOperator = null;
      shouldClearDisplay = true;
    } else if (keyValue === '^') {
      display.value = displayValue + "**";
      lastOperator = null;
      shouldClearDisplay = false;
    } else if (keyValue === 'suppr') {
      display.value = displayValue.slice(0, -1);
      lastOperator = null;
      shouldClearDisplay = false;
    } else if (keyValue === '+' || keyValue === '-' || keyValue === '*' || keyValue === '/') {
      const lastChar = displayValue.slice(-1);
      if (lastChar === '+' || lastChar === '-' || lastChar === '*' || lastChar === '/') {
        display.value = displayValue.slice(0, -1) + keyValue;
      } else if (lastOperator !== null) {
        const result = eval(displayValue.slice(0, -1));
        display.value = result.toPrecision(6) + keyValue;
      } else {
        display.value = displayValue + keyValue;
      }
      lastOperator = keyValue;
      shouldClearDisplay = false;
    } else {
      if (shouldClearDisplay) {
        display.value = keyValue;
        shouldClearDisplay = false;
      } else {
        display.value = displayValue + keyValue;
      }
      lastOperator = null;
    }
  });
});
