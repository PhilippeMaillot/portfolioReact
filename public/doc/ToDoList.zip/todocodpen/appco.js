// Récupérer les éléments HTML (via le DOM)
const input = document.querySelector('.todo-input');
const submit = document.querySelector('.submit');
const todoList = document.querySelector('.todo-list');


// Les écouteurs d'événements 
submit.addEventListener('click', addTodo);
todoList.addEventListener('click', deleteTodo);
todoList.addEventListener('click', checkTodo);
document.addEventListener('DOMContentLoaded', getTodos)

input.addEventListener("keyup", function(e) {
    if (e.key === 'Enter') {
        addTodo();
    }}
)

// Fonctions
function addTodo() {
    if (!input.value == '') {
        // Créer la todo
        const newTodo = document.createElement('li'); 
        newTodo.classList.add('todo-item');
        newTodo.textContent = input.value;
        todoList.appendChild(newTodo);

        // On appelle la fonction définie plus bas (saveLocalTodos())
        saveLocalTodos(input.value)

        input.value = '';

        // Rajouter le btn delete
        const deleteBtn = document.createElement('div');
        deleteBtn.classList.add('delete-btn');
        deleteBtn.textContent = 'x';
        newTodo.appendChild(deleteBtn);

        // Rajouter le check
        const checkBtn = document.createElement('div');
        checkBtn.classList.add('check-btn');
        checkBtn.textContent = 'check';
        newTodo.appendChild(checkBtn);
    }   
}

function deleteTodo(e) {
    // On vient récupérer la Todo qui est l'élément parent de la 
    // cible de notre cllique
    const todo = e.target.parentElement;

    // Si la cible de notre clique a pour classe delete-btn on supprime 
    // la todo
    if (e.target.classList.contains('delete-btn')) {
        todo.remove();

        deleteLocalTodos(todo)
    }
}

function checkTodo(event) {
    const todo = event.target.parentElement;

    if (event.target.classList.contains('check-btn')) {
        todo.classList.toggle('checked');
    }
}


////// LOCAL STORAGE ////// 



function saveLocalTodos(todo) {
    let todos;

    // On vérifie si il y a des éléments dans notre todos du LS
    // Si non on a un tableau vide pour todos, si oui on récupère 
    // todos 
    if (localStorage.getItem('todos') == null) {
        todos = []
    } else {
        todos = JSON.parse(localStorage.getItem('todos'))
    }

    /// Ajouter la todo à un tableau todos (qui contient les todos)
    /// Ajouter le tableau dans localStorage (JSON.stringify)
    todos.push(todo)
    localStorage.setItem('todos', JSON.stringify(todos))
}

function deleteLocalTodos(todo) {
    let todos;

    // On vérifie si il y a des éléments dans notre todos du LS
    // Si non on a un tableau vide pour todos, si oui on récupère 
    // todos 
    if (localStorage.getItem('todos') == null) {
        todos = []
    } else {
        todos = JSON.parse(localStorage.getItem('todos'))
    }

    const todoIndex = todo.textContent.replace('xcheck', '')
    
    /// Supprimer la todo du tableau todos
    /// Mis à jour du tableau dans localStorage
    todos.splice(todos.indexOf(todoIndex))
    localStorage.setItem('todos', JSON.stringify(todos))
}


function getTodos() {
    // Afficher chaque todo contenue dans todos
    let todos;

    if (localStorage.getItem('todos') == null) {
        todos = []
    } else {
        todos = JSON.parse(localStorage.getItem('todos'))
    }

    todos.forEach(todo => {
        // Créer la todo
        const newTodo = document.createElement('li'); 
        newTodo.classList.add('todo-item');
        newTodo.textContent = todo;
        todoList.appendChild(newTodo);

        input.value = '';

        // Rajouter le btn delete
        const deleteBtn = document.createElement('div');
        deleteBtn.classList.add('delete-btn');
        deleteBtn.textContent = 'x';
        newTodo.appendChild(deleteBtn);

        // Rajouter le check
        const checkBtn = document.createElement('div');
        checkBtn.classList.add('check-btn');
        checkBtn.textContent = 'check';
        newTodo.appendChild(checkBtn);
    })

}

console.log(localStorage)