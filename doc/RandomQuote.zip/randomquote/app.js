    const citationDiv = document.getElementById('citation');
    const texteP = document.getElementById('texte');
    const auteurP = document.getElementById('auteur');
    const refreshBtn = document.getElementById('refresh');

    async function fetchCitation() {
      try {
        const response = await axios.get('https://type.fit/api/quotes');
        const data = response.data;
        const randomIndex = Math.floor(Math.random() * data.length);
        const citation = data[randomIndex];
        texteP.textContent = citation.text;
        auteurP.textContent = citation.author || '...';
      } catch (error) {
        console.error(error);
      }
    }

    refreshBtn.addEventListener('click', fetchCitation);

    fetchCitation();