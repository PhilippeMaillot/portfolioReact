const textInput = document.getElementById('text-input');
const inputBtn = document.querySelector('.input');
const content = document.querySelector('.content');

inputBtn.addEventListener('click', () => {
  content.innerHTML = textInput.value;
});