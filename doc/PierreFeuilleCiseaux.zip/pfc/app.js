const options = ['pierre', 'feuille', 'ciseaux'];
      const rockImage = document.getElementById('rock-image');
      const paperImage = document.getElementById('paper-image');
      const scissorsImage = document.getElementById('scissors-image');
      const resultElement = document.getElementById('result');
      
      function play(playerOption) {
        const computerOption = options[Math.floor(Math.random() * options.length)];
        let result;
        
        if (playerOption === computerOption) {
          result = "Égalité !";
        } else if (
          (playerOption === 'pierre' && computerOption === 'ciseaux') ||
          (playerOption === 'feuille' && computerOption === 'pierre') ||
          (playerOption === 'ciseaux' && computerOption === 'feuille')
        ) {
          result = "Vous avez gagné !";
        } else {
          result = "L'ordinateur a gagné !";
        }
        
        resultElement.textContent = `Vous avez choisi ${playerOption}. L'ordinateur a choisi ${computerOption}. ${result}`;
      }
      
      rockImage.addEventListener('click', () => play('pierre'));
      paperImage.addEventListener('click', () => play('feuille'));
      scissorsImage.addEventListener('click', () => play('ciseaux'));